import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { LayoutDashboard, Package, ShoppingBag, LogOut, Store, Link2, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";

export function AdminLayout({ children }: { children: React.ReactNode }) {
  const { logout, user } = useAuth();
  const [location] = useLocation();

  if (user?.role !== "admin") {
    return null;
  }

  const navItems = [
    { href: "/admin", label: "الرئيسية", icon: LayoutDashboard },
    { href: "/admin/products", label: "المنتجات", icon: Package },
    { href: "/admin/orders", label: "الطلبات", icon: ShoppingBag },
    { href: "/admin/pos-settings", label: "ربط الكاشير", icon: Link2 },
    { href: "/admin/settings", label: "الإعدادات", icon: Settings },
  ];

  return (
    <div className="min-h-[100dvh] flex flex-col md:flex-row bg-gray-50 font-sans">
      <aside className="w-full md:w-64 bg-white border-l shadow-sm flex-shrink-0 md:h-[100dvh] md:sticky md:top-0 flex flex-col">
        <div className="p-6 border-b">
          <Link href="/" className="flex items-center gap-2 text-primary hover:opacity-80">
            <Store className="h-6 w-6" />
            <span className="text-2xl font-bold tracking-tight">الصافي</span>
          </Link>
          <p className="text-xs text-gray-500 mt-1">لوحة تحكم الإدارة</p>
        </div>

        <nav className="p-4 flex flex-col gap-1 flex-1">
          {navItems.map((item) => {
            const isActive = location === item.href;
            return (
              <Link key={item.href} href={item.href}>
                <Button
                  variant={isActive ? "secondary" : "ghost"}
                  className={`w-full justify-start gap-3 ${isActive ? "bg-green-50 text-primary font-bold" : "text-gray-600 hover:text-primary hover:bg-green-50"}`}
                >
                  <item.icon className="h-5 w-5 flex-shrink-0" />
                  {item.label}
                </Button>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t">
          <Button variant="ghost" className="w-full justify-start gap-3 text-gray-500 hover:text-destructive hover:bg-red-50" onClick={() => logout()}>
            <LogOut className="h-5 w-5" />
            تسجيل الخروج
          </Button>
        </div>
      </aside>

      <main className="flex-1 p-6 md:p-8 overflow-x-hidden">
        {children}
      </main>
    </div>
  );
}
