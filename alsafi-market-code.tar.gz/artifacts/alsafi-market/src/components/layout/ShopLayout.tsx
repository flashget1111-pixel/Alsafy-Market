import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { useCart } from "@/lib/cart";
import { ShoppingCart, LogOut, Package, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export function ShopLayout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const { items } = useCart();
  const [location] = useLocation();

  const cartCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-[100dvh] flex flex-col bg-gray-50 text-gray-900 font-sans">
      <header className="sticky top-0 z-50 w-full border-b bg-white shadow-sm">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <Link href="/" className="flex items-center gap-2">
              <span className="text-2xl font-bold text-primary tracking-tight">الصافي</span>
            </Link>
          </div>

          <div className="flex items-center gap-4">
            <Link href="/cart">
              <Button variant="ghost" size="icon" className="relative text-gray-700 hover:text-primary hover:bg-green-50">
                <ShoppingCart className="h-5 w-5" />
                {cartCount > 0 && (
                  <Badge variant="destructive" className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs rounded-full">
                    {cartCount}
                  </Badge>
                )}
              </Button>
            </Link>

            {user?.role === "admin" && (
              <Link href="/admin">
                <Button variant="outline" size="sm" className="hidden sm:flex text-gray-700 border-gray-200">
                  لوحة الإدارة
                </Button>
              </Link>
            )}

            <Button variant="ghost" size="sm" onClick={() => logout()} className="text-gray-500 hover:text-destructive">
              <LogOut className="h-4 w-4 ml-2" />
              <span className="hidden sm:inline">تسجيل الخروج</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        {children}
      </main>

      <footer className="border-t bg-white py-6 mt-auto">
        <div className="container mx-auto px-4 text-center text-sm text-gray-500">
          © {new Date().getFullYear()} سوبر ماركت الصافي. جميع الحقوق محفوظة.
        </div>
      </footer>
    </div>
  );
}
