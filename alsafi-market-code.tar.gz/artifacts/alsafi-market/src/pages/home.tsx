import { useState } from "react";
import { useGetProducts, getGetProductsQueryKey } from "@workspace/api-client-react";
import { useCart } from "@/lib/cart";
import { useDebounce } from "@/hooks/use-debounce";
import { ShopLayout } from "@/components/layout/ShopLayout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, ShoppingCart, Plus, Minus, Image as ImageIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const debouncedSearch = useDebounce(searchQuery, 300);
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>();
  
  const { data: products, isLoading } = useGetProducts(
    { search: debouncedSearch || undefined, category: selectedCategory },
    { query: { queryKey: getGetProductsQueryKey({ search: debouncedSearch || undefined, category: selectedCategory }) } }
  );

  const { items, addToCart, removeFromCart, updateQuantity } = useCart();
  const { toast } = useToast();

  const categories = ["الكل", "خضروات وفواكه", "لحوم", "ألبان وأجبان", "مخبوزات", "معلبات", "مشروبات", "منظفات", "أخرى"];

  const handleAddToCart = (product: any) => {
    addToCart({
      productId: product.id,
      productName: product.name,
      price: product.price,
      maxQuantity: product.quantity,
      imageUrl: product.imageUrl,
      quantity: 1,
    });
    toast({
      title: "تمت الإضافة",
      description: `تم إضافة ${product.name} إلى السلة.`,
    });
  };

  return (
    <ShopLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center bg-white p-4 rounded-xl shadow-sm border">
          <div className="relative w-full md:w-96">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input
              placeholder="ابحث عن منتجات..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10 bg-gray-50 border-transparent focus-visible:ring-primary"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <Badge
                key={cat}
                variant={selectedCategory === cat || (cat === "الكل" && !selectedCategory) ? "default" : "outline"}
                className="cursor-pointer text-sm py-1 px-3"
                onClick={() => setSelectedCategory(cat === "الكل" ? undefined : cat)}
              >
                {cat}
              </Badge>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {isLoading ? (
            Array.from({ length: 8 }).map((_, i) => (
              <Card key={i} className="overflow-hidden border-transparent shadow-sm">
                <Skeleton className="h-48 w-full" />
                <CardContent className="p-4">
                  <Skeleton className="h-5 w-2/3 mb-2" />
                  <Skeleton className="h-4 w-1/2" />
                </CardContent>
                <CardFooter className="p-4 pt-0">
                  <Skeleton className="h-10 w-full" />
                </CardFooter>
              </Card>
            ))
          ) : products?.length === 0 ? (
            <div className="col-span-full py-12 text-center text-gray-500 bg-white rounded-xl border border-dashed">
              <ShoppingCart className="mx-auto h-12 w-12 text-gray-300 mb-3" />
              <h3 className="text-lg font-medium text-gray-900 mb-1">لا توجد منتجات</h3>
              <p>لم نتمكن من العثور على منتجات تطابق بحثك.</p>
            </div>
          ) : (
            products?.map((product) => {
              const cartItem = items.find((i) => i.productId === product.id);
              const isOutOfStock = product.quantity === 0;

              return (
                <Card key={product.id} className="overflow-hidden group hover:shadow-md transition-all duration-200 border-gray-100 flex flex-col">
                  <div className="aspect-square bg-gray-50 relative overflow-hidden flex items-center justify-center border-b">
                    {product.imageUrl ? (
                      <img
                        src={product.imageUrl}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="text-gray-300 flex flex-col items-center">
                        <ImageIcon className="h-12 w-12 mb-2 opacity-50" />
                        <span className="text-xs font-medium">{product.category}</span>
                      </div>
                    )}
                    {isOutOfStock && (
                      <div className="absolute inset-0 bg-white/60 backdrop-blur-[2px] flex items-center justify-center">
                        <Badge variant="destructive" className="text-sm py-1 px-3 shadow-lg">نفذت الكمية</Badge>
                      </div>
                    )}
                  </div>
                  
                  <CardContent className="p-4 flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-bold text-gray-900 line-clamp-1">{product.name}</h3>
                        <p className="text-sm text-gray-500">{product.category}</p>
                      </div>
                      <span className="font-bold text-primary text-lg whitespace-nowrap">
                        {product.price.toFixed(2)} ج.م
                      </span>
                    </div>
                  </CardContent>
                  
                  <CardFooter className="p-4 pt-0 mt-auto">
                    {cartItem ? (
                      <div className="w-full flex items-center justify-between bg-green-50 rounded-lg p-1 border border-green-100">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-green-700 hover:text-green-800 hover:bg-green-200 rounded-md"
                          onClick={() => {
                            if (cartItem.quantity > 1) {
                              updateQuantity(product.id, cartItem.quantity - 1);
                            } else {
                              removeFromCart(product.id);
                            }
                          }}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <span className="font-bold text-green-800 w-8 text-center">{cartItem.quantity}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-green-700 hover:text-green-800 hover:bg-green-200 rounded-md"
                          onClick={() => updateQuantity(product.id, cartItem.quantity + 1)}
                          disabled={cartItem.quantity >= product.quantity}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                    ) : (
                      <Button
                        className="w-full font-bold shadow-sm"
                        onClick={() => handleAddToCart(product)}
                        disabled={isOutOfStock}
                      >
                        <ShoppingCart className="h-4 w-4 ml-2" />
                        أضف للسلة
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              );
            })
          )}
        </div>
      </div>
    </ShopLayout>
  );
}
