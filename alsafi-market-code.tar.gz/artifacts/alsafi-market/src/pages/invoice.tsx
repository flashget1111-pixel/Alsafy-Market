import { useRoute } from "wouter";
import { useGetOrder, getGetOrderQueryKey } from "@workspace/api-client-react";
import { ShopLayout } from "@/components/layout/ShopLayout";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Printer, Store, Loader2, ArrowRight } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export default function Invoice() {
  const [, params] = useRoute("/invoice/:id");
  const orderId = params?.id ? parseInt(params.id) : 0;

  const { data: order, isLoading } = useGetOrder(orderId, {
    query: { enabled: !!orderId, queryKey: getGetOrderQueryKey(orderId) }
  });

  if (isLoading) {
    return (
      <ShopLayout>
        <div className="min-h-[50vh] flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </ShopLayout>
    );
  }

  if (!order) {
    return (
      <ShopLayout>
        <div className="text-center py-20">
          <h2 className="text-2xl font-bold mb-2">لم يتم العثور على الفاتورة</h2>
        </div>
      </ShopLayout>
    );
  }

  const statusLabel = order.status === "pending" ? "قيد الانتظار" :
    order.status === "processing" ? "قيد التنفيذ" :
    order.status === "completed" ? "مكتمل" : "ملغي";

  return (
    <ShopLayout>
      <div className="max-w-2xl mx-auto print:max-w-none print:w-full print:m-0">
        <div className="flex justify-between items-center mb-6 print:hidden">
          <Button variant="outline" onClick={() => window.history.back()}>
            <ArrowRight className="h-4 w-4 ml-2" />
            رجوع
          </Button>
          <Button onClick={() => window.print()} className="font-bold">
            <Printer className="h-4 w-4 ml-2" />
            طباعة الفاتورة
          </Button>
        </div>

        <Card className="shadow-lg border-0 print:shadow-none print:border-0 rounded-none bg-white invoice-container">
          <CardHeader className="text-center border-b pb-6 print:pb-4">
            <div className="mx-auto w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mb-4 print:border-2 print:border-black print:bg-white print:text-black">
              <Store className="h-8 w-8" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-1 print:text-black">سوبر ماركت الصافي</h1>
            <p className="text-gray-500 print:text-black">فاتورة ضريبية مبسطة</p>
          </CardHeader>
          
          <CardContent className="p-8 print:p-0 print:pt-4">
            <div className="grid grid-cols-2 gap-8 mb-8">
              <div className="space-y-1 text-sm">
                <p><span className="text-gray-500 font-medium w-24 inline-block print:text-black">رقم الطلب:</span> <span className="font-bold">{order.orderNumber}</span></p>
                <p><span className="text-gray-500 font-medium w-24 inline-block print:text-black">التاريخ:</span> {format(new Date(order.createdAt), "dd MMMM yyyy - hh:mm a", { locale: ar })}</p>
                <p><span className="text-gray-500 font-medium w-24 inline-block print:text-black">حالة الطلب:</span> {statusLabel}</p>
              </div>
              <div className="space-y-1 text-sm bg-gray-50 p-4 rounded-lg print:bg-transparent print:border print:p-2 print:rounded-none">
                <p><span className="text-gray-500 font-medium w-20 inline-block print:text-black">العميل:</span> {order.customerName || "عميل"}</p>
                {order.customerPhone && <p><span className="text-gray-500 font-medium w-20 inline-block print:text-black">الهاتف:</span> <span dir="ltr" className="inline-block">{order.customerPhone}</span></p>}
                <p className="flex"><span className="text-gray-500 font-medium w-20 inline-block flex-shrink-0 print:text-black">العنوان:</span> <span className="line-clamp-2">{order.customerAddress}</span></p>
              </div>
            </div>

            <table className="w-full text-sm mb-8 print:mb-4">
              <thead>
                <tr className="border-b-2 border-gray-200 print:border-black">
                  <th className="py-3 text-right font-bold print:py-2">المنتج</th>
                  <th className="py-3 text-center font-bold print:py-2">الكمية</th>
                  <th className="py-3 text-center font-bold print:py-2">السعر (ج.م)</th>
                  <th className="py-3 text-left font-bold print:py-2">المجموع (ج.م)</th>
                </tr>
              </thead>
              <tbody className="divide-y border-b-2 border-gray-200 print:border-black">
                {order.items.map((item, i) => (
                  <tr key={i}>
                    <td className="py-4 text-right print:py-2">{item.productName}</td>
                    <td className="py-4 text-center print:py-2">{item.quantity}</td>
                    <td className="py-4 text-center print:py-2">{item.unitPrice.toFixed(2)}</td>
                    <td className="py-4 text-left font-medium print:py-2">{item.totalPrice.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="flex justify-end mb-12 print:mb-8">
              <div className="w-64 space-y-3 print:w-1/2">
                <div className="flex justify-between text-gray-600 print:text-black">
                  <span>المجموع الفرعي</span>
                  <span>{order.totalAmount.toFixed(2)} ج.م</span>
                </div>
                <Separator className="print:border-black print:border-b" />
                <div className="flex justify-between text-lg font-bold">
                  <span>الإجمالي المطلوب</span>
                  <span className="text-primary print:text-black">{order.totalAmount.toFixed(2)} ج.م</span>
                </div>
              </div>
            </div>

            {order.notes && (
              <div className="mb-8 p-4 bg-yellow-50 text-yellow-800 rounded-lg text-sm print:border print:bg-transparent print:text-black print:p-2 print:rounded-none">
                <span className="font-bold block mb-1">ملاحظات الطلب:</span>
                {order.notes}
              </div>
            )}

            <div className="text-center text-gray-500 text-sm border-t pt-8 print:pt-4 print:text-black">
              <p className="font-medium text-gray-900 mb-1 print:text-black">شكراً لتسوقكم من سوبر ماركت الصافي!</p>
              <p>نأمل أن نراكم قريباً</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <style>{`
        @media print {
          body { background: white; }
          .print\\:hidden { display: none !important; }
          header, footer, nav { display: none !important; }
          main { padding: 0 !important; }
          .invoice-container { box-shadow: none !important; border: none !important; }
          @page { margin: 1cm; }
        }
      `}</style>
    </ShopLayout>
  );
}
