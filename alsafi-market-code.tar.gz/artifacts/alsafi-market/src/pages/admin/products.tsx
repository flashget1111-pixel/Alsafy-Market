import { useState } from "react";
import { useGetProducts, getGetProductsQueryKey, useCreateProduct, useUpdateProduct, useDeleteProduct } from "@workspace/api-client-react";
import { AdminLayout } from "@/components/layout/AdminLayout";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Plus, Edit, Trash2, Search, Package, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Product } from "@workspace/api-client-react/src/generated/api.schemas";
import { useDebounce } from "@/hooks/use-debounce";

const DEFAULT_FORM_STATE = { name: "", price: 0, quantity: 0, category: "", imageUrl: "", description: "" };

export default function AdminProducts() {
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebounce(search, 300);
  
  const { data: products, isLoading } = useGetProducts(
    { search: debouncedSearch || undefined },
    { query: { queryKey: getGetProductsQueryKey({ search: debouncedSearch || undefined }) } }
  );

  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const createProduct = useCreateProduct();
  const updateProduct = useUpdateProduct();
  const deleteProduct = useDeleteProduct();

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [deletingProduct, setDeletingProduct] = useState<Product | null>(null);
  const [formData, setFormData] = useState(DEFAULT_FORM_STATE);

  const handleOpenForm = (product?: Product) => {
    if (product) {
      setEditingProduct(product);
      setFormData({
        name: product.name,
        price: product.price,
        quantity: product.quantity,
        category: product.category,
        imageUrl: product.imageUrl || "",
        description: product.description || ""
      });
    } else {
      setEditingProduct(null);
      setFormData(DEFAULT_FORM_STATE);
    }
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const payload = {
      ...formData,
      imageUrl: formData.imageUrl || null,
      description: formData.description || null
    };

    if (editingProduct) {
      updateProduct.mutate({ id: editingProduct.id, data: payload }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetProductsQueryKey() });
          toast({ title: "تم التحديث", description: "تم تحديث المنتج بنجاح." });
          setIsFormOpen(false);
        },
        onError: () => toast({ variant: "destructive", title: "خطأ", description: "حدث خطأ أثناء تحديث المنتج." })
      });
    } else {
      createProduct.mutate({ data: payload }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetProductsQueryKey() });
          toast({ title: "تمت الإضافة", description: "تمت إضافة المنتج بنجاح." });
          setIsFormOpen(false);
        },
        onError: () => toast({ variant: "destructive", title: "خطأ", description: "حدث خطأ أثناء إضافة المنتج." })
      });
    }
  };

  const confirmDelete = () => {
    if (!deletingProduct) return;
    deleteProduct.mutate({ id: deletingProduct.id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetProductsQueryKey() });
        toast({ title: "تم الحذف", description: "تم حذف المنتج بنجاح." });
        setIsDeleteOpen(false);
      },
      onError: () => toast({ variant: "destructive", title: "خطأ", description: "حدث خطأ أثناء حذف المنتج." })
    });
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">إدارة المنتجات</h1>
            <p className="text-gray-500">إضافة، تعديل، وحذف منتجات المتجر</p>
          </div>
          <Button onClick={() => handleOpenForm()} className="font-bold shadow-sm">
            <Plus className="h-5 w-5 ml-2" />
            إضافة منتج جديد
          </Button>
        </div>

        <Card className="shadow-sm border-0 overflow-hidden">
          <div className="p-4 border-b bg-gray-50/50">
            <div className="relative w-full max-w-md">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="البحث باسم المنتج..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-10 bg-white"
              />
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-gray-50">
                <TableRow>
                  <TableHead className="font-bold text-right w-[80px]">صورة</TableHead>
                  <TableHead className="font-bold text-right">اسم المنتج</TableHead>
                  <TableHead className="font-bold text-right">القسم</TableHead>
                  <TableHead className="font-bold text-center">السعر</TableHead>
                  <TableHead className="font-bold text-center">المخزون</TableHead>
                  <TableHead className="font-bold text-left">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><div className="w-10 h-10 bg-gray-100 rounded animate-pulse" /></TableCell>
                      <TableCell><div className="h-4 w-40 bg-gray-100 rounded animate-pulse" /></TableCell>
                      <TableCell><div className="h-4 w-20 bg-gray-100 rounded animate-pulse" /></TableCell>
                      <TableCell><div className="h-4 w-16 bg-gray-100 rounded mx-auto animate-pulse" /></TableCell>
                      <TableCell><div className="h-4 w-12 bg-gray-100 rounded mx-auto animate-pulse" /></TableCell>
                      <TableCell><div className="h-8 w-20 bg-gray-100 rounded mr-auto animate-pulse" /></TableCell>
                    </TableRow>
                  ))
                ) : products?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-10 text-gray-500">
                      <Package className="h-10 w-10 mx-auto text-gray-300 mb-2" />
                      لا توجد منتجات مطابقة
                    </TableCell>
                  </TableRow>
                ) : (
                  products?.map((product) => (
                    <TableRow key={product.id} className="hover:bg-green-50/30 transition-colors">
                      <TableCell>
                        {product.imageUrl ? (
                          <img src={product.imageUrl} alt={product.name} className="w-10 h-10 rounded object-cover border" />
                        ) : (
                          <div className="w-10 h-10 rounded bg-gray-100 border flex items-center justify-center text-gray-400 text-xs">
                            <Package className="h-5 w-5" />
                          </div>
                        )}
                      </TableCell>
                      <TableCell className="font-medium text-gray-900">{product.name}</TableCell>
                      <TableCell>
                        <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs font-medium">{product.category}</span>
                      </TableCell>
                      <TableCell className="text-center font-bold text-primary">{product.price.toFixed(2)} ج.م</TableCell>
                      <TableCell className="text-center">
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-bold ${
                          product.quantity === 0 ? 'bg-red-100 text-red-800' : 
                          product.quantity < 10 ? 'bg-amber-100 text-amber-800' : 'bg-green-100 text-green-800'
                        }`}>
                          {product.quantity}
                        </span>
                      </TableCell>
                      <TableCell className="text-left">
                        <div className="flex justify-end gap-2">
                          <Button variant="outline" size="sm" className="h-8 bg-white" onClick={() => handleOpenForm(product)}>
                            <Edit className="h-4 w-4 ml-1" />
                            تعديل
                          </Button>
                          <Button variant="outline" size="sm" className="h-8 text-destructive border-red-200 hover:bg-red-50 hover:text-destructive" onClick={() => { setDeletingProduct(product); setIsDeleteOpen(true); }}>
                            <Trash2 className="h-4 w-4 ml-1" />
                            حذف
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>

      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-[500px]" dir="rtl">
          <form onSubmit={handleSubmit}>
            <DialogHeader>
              <DialogTitle>{editingProduct ? "تعديل المنتج" : "إضافة منتج جديد"}</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">اسم المنتج <span className="text-destructive">*</span></Label>
                <Input id="name" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="col-span-3" required />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="category" className="text-right">القسم <span className="text-destructive">*</span></Label>
                <Input id="category" value={formData.category} onChange={(e) => setFormData({...formData, category: e.target.value})} className="col-span-3" required placeholder="خضروات، ألبان..." />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="price" className="text-right">السعر <span className="text-destructive">*</span></Label>
                <Input id="price" type="number" step="0.01" min="0" value={formData.price} onChange={(e) => setFormData({...formData, price: parseFloat(e.target.value)})} className="col-span-3" required dir="ltr" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="quantity" className="text-right">المخزون <span className="text-destructive">*</span></Label>
                <Input id="quantity" type="number" min="0" value={formData.quantity} onChange={(e) => setFormData({...formData, quantity: parseInt(e.target.value)})} className="col-span-3" required dir="ltr" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="imageUrl" className="text-right">رابط الصورة</Label>
                <Input id="imageUrl" value={formData.imageUrl} onChange={(e) => setFormData({...formData, imageUrl: e.target.value})} className="col-span-3" dir="ltr" placeholder="https://..." />
              </div>
              <div className="grid grid-cols-4 items-start gap-4">
                <Label htmlFor="description" className="text-right pt-2">الوصف</Label>
                <textarea id="description" value={formData.description} onChange={(e) => setFormData({...formData, description: e.target.value})} className="col-span-3 min-h-[80px] rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50" />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsFormOpen(false)}>إلغاء</Button>
              <Button type="submit" disabled={createProduct.isPending || updateProduct.isPending}>
                {(createProduct.isPending || updateProduct.isPending) && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
                {editingProduct ? "حفظ التعديلات" : "إضافة المنتج"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>هل أنت متأكد من الحذف؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم حذف منتج "{deletingProduct?.name}" نهائياً ولن يمكنك استعادته.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-row-reverse sm:space-x-reverse space-x-2">
            <AlertDialogCancel className="mt-0">إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90" disabled={deleteProduct.isPending}>
              {deleteProduct.isPending ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : null}
              نعم، احذف المنتج
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}
