import { useGetOrders, getGetOrdersQueryKey, useUpdateOrderStatus } from "@workspace/api-client-react";
import { AdminLayout } from "@/components/layout/AdminLayout";
import { useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Eye, Clock, CheckCircle2, ShoppingBag, MapPin, Loader2, ArrowUpRight, Package } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { useState } from "react";
import { Order, UpdateOrderStatusBodyStatus } from "@workspace/api-client-react/src/generated/api.schemas";
import { Link } from "wouter";

const statusConfig: Record<string, { label: string; color: string }> = {
  pending: { label: "قيد الانتظار", color: "bg-amber-100 text-amber-800 border-amber-200" },
  processing: { label: "قيد التنفيذ", color: "bg-blue-100 text-blue-800 border-blue-200" },
  completed: { label: "مكتمل", color: "bg-green-100 text-green-800 border-green-200" },
  cancelled: { label: "ملغي", color: "bg-red-100 text-red-800 border-red-200" }
};

export default function AdminOrders() {
  const { data: orders, isLoading } = useGetOrders({ query: { queryKey: getGetOrdersQueryKey() } });
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const updateStatus = useUpdateOrderStatus();
  
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const handleStatusChange = (orderId: number, newStatus: UpdateOrderStatusBodyStatus) => {
    updateStatus.mutate(
      { id: orderId, data: { status: newStatus } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetOrdersQueryKey() });
          toast({ title: "تم تحديث الحالة", description: "تم تحديث حالة الطلب بنجاح." });
          if (selectedOrder && selectedOrder.id === orderId) {
            setSelectedOrder({ ...selectedOrder, status: newStatus });
          }
        },
        onError: () => toast({ variant: "destructive", title: "خطأ", description: "حدث خطأ أثناء التحديث." })
      }
    );
  };

  const getStatusConfig = (status: string) => statusConfig[status] || statusConfig.pending;

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">إدارة الطلبات</h1>
          <p className="text-gray-500">متابعة وتحديث حالات طلبات العملاء</p>
        </div>

        <Card className="shadow-sm border-0 overflow-hidden bg-white">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-gray-50">
                <TableRow>
                  <TableHead className="font-bold text-right">رقم الطلب</TableHead>
                  <TableHead className="font-bold text-right">العميل</TableHead>
                  <TableHead className="font-bold text-right">التاريخ</TableHead>
                  <TableHead className="font-bold text-center">القيمة</TableHead>
                  <TableHead className="font-bold text-center">الحالة</TableHead>
                  <TableHead className="font-bold text-left">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><div className="h-4 w-24 bg-gray-100 rounded animate-pulse" /></TableCell>
                      <TableCell><div className="h-4 w-32 bg-gray-100 rounded animate-pulse" /></TableCell>
                      <TableCell><div className="h-4 w-28 bg-gray-100 rounded animate-pulse" /></TableCell>
                      <TableCell><div className="h-4 w-16 bg-gray-100 rounded mx-auto animate-pulse" /></TableCell>
                      <TableCell><div className="h-8 w-24 bg-gray-100 rounded mx-auto animate-pulse" /></TableCell>
                      <TableCell><div className="h-8 w-24 bg-gray-100 rounded mr-auto animate-pulse" /></TableCell>
                    </TableRow>
                  ))
                ) : !orders || orders.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-12 text-gray-500">
                      <ShoppingBag className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                      لا توجد طلبات مسجلة
                    </TableCell>
                  </TableRow>
                ) : (
                  orders.map((order) => (
                    <TableRow key={order.id} className="hover:bg-gray-50 transition-colors">
                      <TableCell className="font-bold text-gray-900">{order.orderNumber}</TableCell>
                      <TableCell>
                        <div className="font-medium text-gray-900">{order.customerName || "بدون اسم"}</div>
                        <div className="text-xs text-gray-500 font-sans" dir="ltr">{order.customerPhone || "-"}</div>
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">
                        {format(new Date(order.createdAt), "dd MMM yyyy", { locale: ar })}
                      </TableCell>
                      <TableCell className="text-center font-bold text-primary">
                        {order.totalAmount.toFixed(2)} ج.م
                      </TableCell>
                      <TableCell className="text-center">
                        <Select 
                          value={order.status} 
                          onValueChange={(val: UpdateOrderStatusBodyStatus) => handleStatusChange(order.id, val)}
                        >
                          <SelectTrigger className={`h-8 border mx-auto w-[130px] ${getStatusConfig(order.status).color}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent dir="rtl">
                            <SelectItem value="pending">قيد الانتظار</SelectItem>
                            <SelectItem value="processing">قيد التنفيذ</SelectItem>
                            <SelectItem value="completed">مكتمل</SelectItem>
                            <SelectItem value="cancelled">ملغي</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell className="text-left">
                        <Button variant="ghost" size="sm" className="text-gray-600 hover:text-primary hover:bg-green-50" onClick={() => setSelectedOrder(order)}>
                          <Eye className="h-4 w-4 ml-1" />
                          التفاصيل
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>

        <Dialog open={!!selectedOrder} onOpenChange={(open) => !open && setSelectedOrder(null)}>
          {selectedOrder && (
            <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto" dir="rtl">
              <DialogHeader>
                <div className="flex justify-between items-center">
                  <DialogTitle className="text-xl">تفاصيل الطلب: {selectedOrder.orderNumber}</DialogTitle>
                  <Link href={`/invoice/${selectedOrder.id}`}>
                    <Button variant="outline" size="sm" className="h-8 ml-6">
                      فاتورة <ArrowUpRight className="h-3 w-3 mr-1" />
                    </Button>
                  </Link>
                </div>
              </DialogHeader>
              
              <div className="space-y-6 mt-4">
                <div className="flex justify-between items-center bg-gray-50 p-4 rounded-lg border">
                  <div>
                    <p className="text-sm text-gray-500 mb-1">الحالة الحالية</p>
                    <Select 
                      value={selectedOrder.status} 
                      onValueChange={(val: UpdateOrderStatusBodyStatus) => handleStatusChange(selectedOrder.id, val)}
                    >
                      <SelectTrigger className={`h-9 border w-[140px] ${getStatusConfig(selectedOrder.status).color}`}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent dir="rtl">
                        <SelectItem value="pending">قيد الانتظار</SelectItem>
                        <SelectItem value="processing">قيد التنفيذ</SelectItem>
                        <SelectItem value="completed">مكتمل</SelectItem>
                        <SelectItem value="cancelled">ملغي</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="text-left">
                    <p className="text-sm text-gray-500 mb-1">تاريخ الطلب</p>
                    <p className="font-medium text-gray-900">{format(new Date(selectedOrder.createdAt), "dd MMMM yyyy HH:mm", { locale: ar })}</p>
                  </div>
                </div>

                <div>
                  <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-primary" /> بيانات التوصيل
                  </h3>
                  <Card className="shadow-none border p-4 bg-white">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500 mb-1">العميل</p>
                        <p className="font-medium">{selectedOrder.customerName || "-"}</p>
                      </div>
                      <div>
                        <p className="text-gray-500 mb-1">الهاتف</p>
                        <p className="font-medium font-sans" dir="ltr">{selectedOrder.customerPhone || "-"}</p>
                      </div>
                      <div className="col-span-2">
                        <p className="text-gray-500 mb-1">العنوان التفصيلي</p>
                        <p className="font-medium bg-gray-50 p-2 rounded border border-gray-100">{selectedOrder.customerAddress}</p>
                      </div>
                      {selectedOrder.notes && (
                        <div className="col-span-2 mt-2">
                          <p className="text-gray-500 mb-1">ملاحظات العميل</p>
                          <p className="font-medium text-amber-800 bg-amber-50 p-2 rounded border border-amber-100">{selectedOrder.notes}</p>
                        </div>
                      )}
                    </div>
                  </Card>
                </div>

                <div>
                  <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <Package className="h-4 w-4 text-primary" /> المنتجات المطلوبة ({selectedOrder.items.length})
                  </h3>
                  <div className="border rounded-lg overflow-hidden">
                    <Table>
                      <TableHeader className="bg-gray-50">
                        <TableRow>
                          <TableHead className="text-right">المنتج</TableHead>
                          <TableHead className="text-center w-20">الكمية</TableHead>
                          <TableHead className="text-center w-28">السعر</TableHead>
                          <TableHead className="text-left w-28">المجموع</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {selectedOrder.items.map((item, idx) => (
                          <TableRow key={idx}>
                            <TableCell className="font-medium">{item.productName}</TableCell>
                            <TableCell className="text-center">{item.quantity}</TableCell>
                            <TableCell className="text-center">{item.unitPrice.toFixed(2)} ج.م</TableCell>
                            <TableCell className="text-left font-medium">{item.totalPrice.toFixed(2)} ج.م</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                    <div className="bg-gray-50 p-4 border-t flex justify-between items-center">
                      <span className="font-bold text-lg">الإجمالي:</span>
                      <span className="font-bold text-2xl text-primary">{selectedOrder.totalAmount.toFixed(2)} ج.م</span>
                    </div>
                  </div>
                </div>
              </div>
            </DialogContent>
          )}
        </Dialog>
      </div>
    </AdminLayout>
  );
}
