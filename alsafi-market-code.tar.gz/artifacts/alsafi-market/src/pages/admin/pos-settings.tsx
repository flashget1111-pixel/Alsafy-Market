import { useState } from "react";
import { AdminLayout } from "@/components/layout/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Link2, RefreshCw, CheckCircle2, AlertCircle, Server } from "lucide-react";
import { useGetProducts, getGetProductsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

export default function PosSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [apiUrl, setApiUrl] = useState(localStorage.getItem("pos_api_url") || "");
  const [apiKey, setApiKey] = useState(localStorage.getItem("pos_api_key") || "");
  const [isSyncing, setIsSyncing] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [syncResult, setSyncResult] = useState<{ success: boolean; message: string; count?: number } | null>(null);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  const saveSettings = () => {
    localStorage.setItem("pos_api_url", apiUrl);
    localStorage.setItem("pos_api_key", apiKey);
    toast({ title: "تم الحفظ", description: "تم حفظ إعدادات نظام الكاشير." });
  };

  const testConnection = async () => {
    if (!apiUrl) {
      toast({ variant: "destructive", title: "خطأ", description: "يرجى إدخال رابط API أولاً." });
      return;
    }
    setIsTesting(true);
    setTestResult(null);
    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (apiKey) headers["Authorization"] = `Bearer ${apiKey}`;
      const res = await fetch(apiUrl, { method: "GET", headers });
      if (res.ok) {
        setTestResult({ success: true, message: "تم الاتصال بنظام الكاشير بنجاح." });
      } else {
        setTestResult({ success: false, message: `فشل الاتصال - كود الخطأ: ${res.status}` });
      }
    } catch {
      setTestResult({ success: false, message: "تعذر الوصول إلى الرابط. تحقق من الإعدادات." });
    } finally {
      setIsTesting(false);
    }
  };

  const syncFromPos = async () => {
    if (!apiUrl) {
      toast({ variant: "destructive", title: "خطأ", description: "يرجى إدخال رابط API أولاً." });
      return;
    }
    setIsSyncing(true);
    setSyncResult(null);
    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (apiKey) headers["Authorization"] = `Bearer ${apiKey}`;
      const res = await fetch(apiUrl, { method: "GET", headers });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const posProducts = await res.json();

      if (!Array.isArray(posProducts)) {
        setSyncResult({ success: false, message: "بيانات نظام الكاشير غير صحيحة. يجب أن تكون مصفوفة من المنتجات." });
        return;
      }

      let synced = 0;
      for (const item of posProducts) {
        const product = {
          name: item.name || item.product_name || item.title || "منتج غير معروف",
          price: parseFloat(item.price || item.selling_price || 0),
          quantity: parseInt(item.quantity || item.stock || item.qty || 0),
          category: item.category || item.category_name || "عام",
          description: item.description || item.details || null,
          imageUrl: item.image_url || item.image || item.photo || null,
        };

        await fetch("/api/products", {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(product),
        });
        synced++;
      }

      await queryClient.invalidateQueries({ queryKey: getGetProductsQueryKey() });
      setSyncResult({ success: true, message: "تمت المزامنة بنجاح.", count: synced });
      toast({ title: "تمت المزامنة", description: `تم استيراد ${synced} منتج من نظام الكاشير.` });
    } catch (err: any) {
      setSyncResult({ success: false, message: `فشلت المزامنة: ${err.message}` });
      toast({ variant: "destructive", title: "فشلت المزامنة", description: err.message });
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6 max-w-2xl">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">ربط نظام الكاشير</h1>
          <p className="text-gray-500">استيراد المنتجات والكميات تلقائياً من نظام الكاشير الخارجي</p>
        </div>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Server className="h-5 w-5 text-primary" />
              إعدادات الاتصال
            </CardTitle>
            <CardDescription>أدخل بيانات API الخاصة بنظام الكاشير</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="apiUrl">رابط API نظام الكاشير</Label>
              <Input
                id="apiUrl"
                value={apiUrl}
                onChange={(e) => setApiUrl(e.target.value)}
                placeholder="https://pos-system.example.com/api/products"
                dir="ltr"
                className="bg-gray-50"
              />
              <p className="text-xs text-gray-500">يجب أن يعيد الرابط قائمة المنتجات بصيغة JSON</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="apiKey">مفتاح API (اختياري)</Label>
              <Input
                id="apiKey"
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="Bearer token أو API key"
                dir="ltr"
                className="bg-gray-50"
              />
            </div>
            <div className="flex gap-3 pt-2">
              <Button onClick={saveSettings} variant="outline">
                حفظ الإعدادات
              </Button>
              <Button onClick={testConnection} variant="outline" disabled={isTesting}>
                {isTesting ? <Loader2 className="h-4 w-4 ml-2 animate-spin" /> : <Link2 className="h-4 w-4 ml-2" />}
                اختبار الاتصال
              </Button>
            </div>

            {testResult && (
              <div className={`flex items-center gap-2 p-3 rounded-lg text-sm ${testResult.success ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}>
                {testResult.success ? <CheckCircle2 className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
                {testResult.message}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <RefreshCw className="h-5 w-5 text-primary" />
              مزامنة المنتجات
            </CardTitle>
            <CardDescription>استيراد المنتجات من نظام الكاشير إلى متجر الإنترنت</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 text-sm text-blue-800 space-y-1">
              <p className="font-bold">الحقول المتوقعة من API الكاشير:</p>
              <ul className="list-disc list-inside space-y-1 text-blue-700">
                <li><code className="bg-blue-100 px-1 rounded">name</code> أو <code className="bg-blue-100 px-1 rounded">product_name</code> - اسم المنتج</li>
                <li><code className="bg-blue-100 px-1 rounded">price</code> أو <code className="bg-blue-100 px-1 rounded">selling_price</code> - السعر</li>
                <li><code className="bg-blue-100 px-1 rounded">quantity</code> أو <code className="bg-blue-100 px-1 rounded">stock</code> - الكمية</li>
                <li><code className="bg-blue-100 px-1 rounded">category</code> - القسم (اختياري)</li>
                <li><code className="bg-blue-100 px-1 rounded">image_url</code> - صورة المنتج (اختياري)</li>
              </ul>
            </div>

            <Button onClick={syncFromPos} className="w-full h-11 font-bold" disabled={isSyncing || !apiUrl}>
              {isSyncing ? <Loader2 className="h-5 w-5 ml-2 animate-spin" /> : <RefreshCw className="h-5 w-5 ml-2" />}
              {isSyncing ? "جاري المزامنة..." : "مزامنة المنتجات من الكاشير"}
            </Button>

            {syncResult && (
              <div className={`flex items-center gap-2 p-3 rounded-lg text-sm ${syncResult.success ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}>
                {syncResult.success ? <CheckCircle2 className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
                <span>{syncResult.message} {syncResult.count ? `(${syncResult.count} منتج)` : ""}</span>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-sm border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg">ربط قاعدة البيانات المشتركة</CardTitle>
            <CardDescription>إذا كان نظام الكاشير يستخدم نفس قاعدة البيانات</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              يمكن ربط الموقع مباشرة بقاعدة بيانات نظام الكاشير عن طريق إضافة متغير البيئة <code className="bg-gray-100 px-1 rounded">POS_DATABASE_URL</code> في إعدادات النظام، وسيتم تحديث المخزون تلقائياً مع كل عملية بيع.
            </p>
            <div className="bg-gray-50 border rounded-lg p-3 font-mono text-xs dir-ltr text-left" dir="ltr">
              POS_DATABASE_URL=postgresql://user:pass@host:5432/pos_db
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
