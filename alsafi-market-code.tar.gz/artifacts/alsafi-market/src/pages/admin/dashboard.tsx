import { useGetDashboardStats, getGetDashboardStatsQueryKey, useGetLowStockProducts, getGetLowStockProductsQueryKey, useGetRecentOrders, getGetRecentOrdersQueryKey } from "@workspace/api-client-react";
import { AdminLayout } from "@/components/layout/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, ShoppingBag, Banknote, AlertTriangle, ArrowUpRight, CheckCircle2, Clock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export default function AdminDashboard() {
  const { data: stats, isLoading: statsLoading } = useGetDashboardStats({
    query: { queryKey: getGetDashboardStatsQueryKey() }
  });
  
  const { data: lowStock, isLoading: lowStockLoading } = useGetLowStockProducts({
    query: { queryKey: getGetLowStockProductsQueryKey() }
  });

  const { data: recentOrders, isLoading: ordersLoading } = useGetRecentOrders({
    query: { queryKey: getGetRecentOrdersQueryKey() }
  });

  const StatCard = ({ title, value, icon: Icon, colorClass, loading }: any) => (
    <Card className="shadow-sm border-0 bg-white relative overflow-hidden">
      <div className={`absolute right-0 top-0 bottom-0 w-1 ${colorClass}`} />
      <CardContent className="p-6 flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-500 mb-1">{title}</p>
          {loading ? (
            <Skeleton className="h-8 w-24" />
          ) : (
            <h3 className="text-3xl font-bold text-gray-900">{value}</h3>
          )}
        </div>
        <div className={`p-4 rounded-full ${colorClass.replace('bg-', 'bg-opacity-10 text-')}`}>
          <Icon className="h-6 w-6" />
        </div>
      </CardContent>
    </Card>
  );

  return (
    <AdminLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">نظرة عامة</h1>
          <p className="text-gray-500">إحصائيات متجرك اليوم</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard title="إجمالي المبيعات" value={stats?.totalRevenue ? `${stats.totalRevenue.toFixed(0)} ج.م` : "0 ج.م"} icon={Banknote} colorClass="bg-primary text-primary bg-green-50" loading={statsLoading} />
          <StatCard title="إجمالي الطلبات" value={stats?.totalOrders || 0} icon={ShoppingBag} colorClass="bg-blue-500 text-blue-500 bg-blue-50" loading={statsLoading} />
          <StatCard title="المنتجات النشطة" value={stats?.totalProducts || 0} icon={Package} colorClass="bg-purple-500 text-purple-500 bg-purple-50" loading={statsLoading} />
          <StatCard title="طلبات قيد الانتظار" value={stats?.pendingOrders || 0} icon={Clock} colorClass="bg-amber-500 text-amber-500 bg-amber-50" loading={statsLoading} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card className="shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-2 border-b">
                <CardTitle className="text-lg font-bold">أحدث الطلبات</CardTitle>
                <Link href="/admin/orders" className="text-sm text-primary hover:underline flex items-center">
                  عرض الكل
                  <ArrowUpRight className="h-4 w-4 mr-1" />
                </Link>
              </CardHeader>
              <CardContent className="p-0">
                {ordersLoading ? (
                  <div className="p-4 space-y-4">
                    {[1, 2, 3].map(i => <Skeleton key={i} className="h-16 w-full" />)}
                  </div>
                ) : recentOrders?.length === 0 ? (
                  <div className="p-8 text-center text-gray-500">لا توجد طلبات حديثة</div>
                ) : (
                  <div className="divide-y">
                    {recentOrders?.map((order) => (
                      <div key={order.id} className="p-4 hover:bg-gray-50 flex items-center justify-between transition-colors">
                        <div className="flex items-center gap-4">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center
                            ${order.status === 'pending' ? 'bg-amber-100 text-amber-600' : 
                              order.status === 'processing' ? 'bg-blue-100 text-blue-600' : 
                              order.status === 'completed' ? 'bg-green-100 text-green-600' : 
                              'bg-red-100 text-red-600'}`}
                          >
                            {order.status === 'completed' ? <CheckCircle2 className="h-5 w-5" /> : 
                             order.status === 'pending' ? <Clock className="h-5 w-5" /> : 
                             <ShoppingBag className="h-5 w-5" />}
                          </div>
                          <div>
                            <p className="font-bold text-gray-900">{order.orderNumber}</p>
                            <p className="text-sm text-gray-500">{order.customerName || "عميل"} • {format(new Date(order.createdAt), "dd MMM HH:mm", { locale: ar })}</p>
                          </div>
                        </div>
                        <div className="text-left">
                          <p className="font-bold text-gray-900">{order.totalAmount.toFixed(2)} ج.م</p>
                          <span className={`text-xs font-medium px-2 py-1 rounded-full
                            ${order.status === 'pending' ? 'bg-amber-100 text-amber-800' : 
                              order.status === 'processing' ? 'bg-blue-100 text-blue-800' : 
                              order.status === 'completed' ? 'bg-green-100 text-green-800' : 
                              'bg-red-100 text-red-800'}`}
                          >
                            {order.status === 'pending' ? 'قيد الانتظار' : 
                             order.status === 'processing' ? 'قيد التنفيذ' : 
                             order.status === 'completed' ? 'مكتمل' : 'ملغي'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-1">
            <Card className="shadow-sm border-red-100">
              <CardHeader className="bg-red-50/50 pb-4 border-b border-red-100 flex flex-row justify-between items-center">
                <CardTitle className="text-lg font-bold text-red-900 flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-red-500" />
                  نواقص المخزون
                </CardTitle>
                <Link href="/admin/products" className="text-sm text-red-600 hover:underline">
                  إدارة
                </Link>
              </CardHeader>
              <CardContent className="p-0">
                {lowStockLoading ? (
                  <div className="p-4 space-y-3">
                    {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
                  </div>
                ) : lowStock?.length === 0 ? (
                  <div className="p-8 text-center text-gray-500">المخزون بحالة جيدة</div>
                ) : (
                  <div className="divide-y divide-red-50">
                    {lowStock?.map((product) => (
                      <div key={product.id} className="p-4 flex justify-between items-center hover:bg-red-50/30">
                        <div>
                          <p className="font-medium text-gray-900 line-clamp-1">{product.name}</p>
                          <p className="text-xs text-gray-500">{product.category}</p>
                        </div>
                        <div className="text-left flex-shrink-0 ml-2">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold ${product.quantity === 0 ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'}`}>
                            {product.quantity === 0 ? 'نفذت' : `متبقي ${product.quantity}`}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
