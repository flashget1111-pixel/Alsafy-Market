import { useState } from "react";
import { AdminLayout } from "@/components/layout/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Loader2, KeyRound, User, ShieldCheck } from "lucide-react";

export default function AdminSettings() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const [form, setForm] = useState({
    targetUsername: "admin",
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!form.currentPassword || !form.newPassword || !form.confirmPassword) {
      toast({ variant: "destructive", title: "خطأ", description: "يرجى ملء جميع الحقول." });
      return;
    }

    if (form.newPassword !== form.confirmPassword) {
      toast({ variant: "destructive", title: "خطأ", description: "كلمة المرور الجديدة وتأكيدها غير متطابقتين." });
      return;
    }

    if (form.newPassword.length < 4) {
      toast({ variant: "destructive", title: "خطأ", description: "كلمة المرور يجب أن تكون 4 أحرف على الأقل." });
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch("/api/auth/change-password", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetUsername: form.targetUsername,
          currentPassword: form.currentPassword,
          newPassword: form.newPassword,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        toast({ title: "تم التغيير", description: `تم تغيير كلمة مرور المستخدم "${form.targetUsername}" بنجاح.` });
        setForm(prev => ({ ...prev, currentPassword: "", newPassword: "", confirmPassword: "" }));
      } else {
        toast({ variant: "destructive", title: "خطأ", description: data.error || "فشل تغيير كلمة المرور." });
      }
    } catch {
      toast({ variant: "destructive", title: "خطأ", description: "تعذر الاتصال بالخادم." });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6 max-w-xl">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">الإعدادات</h1>
          <p className="text-gray-500">إدارة كلمات مرور المستخدمين</p>
        </div>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <KeyRound className="h-5 w-5 text-primary" />
              تغيير كلمة المرور
            </CardTitle>
            <CardDescription>تغيير كلمة مرور أي مستخدم في النظام</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="targetUsername">المستخدم</Label>
                <div className="relative">
                  <User className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <select
                    id="targetUsername"
                    name="targetUsername"
                    value={form.targetUsername}
                    onChange={handleChange}
                    className="w-full pr-10 h-10 rounded-md border border-input bg-gray-50 px-3 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring appearance-none"
                  >
                    <option value="admin">مدير النظام (admin)</option>
                    <option value="user">المستخدم العادي (user)</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="currentPassword">كلمة المرور الحالية للأدمن</Label>
                <div className="relative">
                  <ShieldCheck className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="currentPassword"
                    name="currentPassword"
                    type="password"
                    value={form.currentPassword}
                    onChange={handleChange}
                    placeholder="أدخل كلمة مرور الأدمن للتحقق"
                    className="pr-10 bg-gray-50"
                    dir="ltr"
                    required
                  />
                </div>
                <p className="text-xs text-gray-500">مطلوب للتحقق من صلاحيتك</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="newPassword">كلمة المرور الجديدة</Label>
                <Input
                  id="newPassword"
                  name="newPassword"
                  type="password"
                  value={form.newPassword}
                  onChange={handleChange}
                  placeholder="كلمة المرور الجديدة"
                  className="bg-gray-50"
                  dir="ltr"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">تأكيد كلمة المرور الجديدة</Label>
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  value={form.confirmPassword}
                  onChange={handleChange}
                  placeholder="أعد إدخال كلمة المرور الجديدة"
                  className="bg-gray-50"
                  dir="ltr"
                  required
                />
              </div>

              <Button type="submit" className="w-full h-11 font-bold mt-2" disabled={isLoading}>
                {isLoading ? <Loader2 className="h-4 w-4 ml-2 animate-spin" /> : <KeyRound className="h-4 w-4 ml-2" />}
                تغيير كلمة المرور
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
