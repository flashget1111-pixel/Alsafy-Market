import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useCart } from "@/lib/cart";
import { useCreateOrder } from "@workspace/api-client-react";
import { ShopLayout } from "@/components/layout/ShopLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { MapPin, User, Phone, CheckCircle2, Loader2, ArrowRight } from "lucide-react";

export default function Checkout() {
  const { items, total, clearCart } = useCart();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const createOrderMutation = useCreateOrder();

  const [formData, setFormData] = useState({
    customerName: "",
    customerPhone: "",
    customerAddress: "",
    notes: "",
  });

  useEffect(() => {
    if (items.length === 0 && !createOrderMutation.isSuccess) {
      setLocation("/");
    }
  }, [items.length, createOrderMutation.isSuccess, setLocation]);

  if (items.length === 0 && !createOrderMutation.isSuccess) {
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.customerAddress) {
      toast({ variant: "destructive", title: "مطلوب", description: "الرجاء إدخال عنوان التوصيل." });
      return;
    }

    const orderData = {
      ...formData,
      customerName: formData.customerName || undefined,
      customerPhone: formData.customerPhone || undefined,
      notes: formData.notes || undefined,
      items: items.map(i => ({ productId: i.productId, quantity: i.quantity })),
    };

    createOrderMutation.mutate(
      { data: orderData },
      {
        onSuccess: (order) => {
          clearCart();
          toast({ title: "تم تأكيد الطلب", description: `طلبك رقم ${order.orderNumber} قيد المعالجة.` });
          setLocation(`/invoice/${order.id}`);
        },
        onError: () => {
          toast({ variant: "destructive", title: "حدث خطأ", description: "لم نتمكن من إتمام الطلب، الرجاء المحاولة مرة أخرى." });
        }
      }
    );
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  return (
    <ShopLayout>
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center mb-6">
          <Link href="/cart" className="text-gray-500 hover:text-gray-900 transition-colors ml-4">
            <ArrowRight className="h-5 w-5" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">إتمام الطلب</h1>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-6">
              <Card className="shadow-sm">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-primary" />
                    بيانات التوصيل
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="customerName">الاسم (اختياري)</Label>
                      <div className="relative">
                        <User className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                        <Input id="customerName" name="customerName" value={formData.customerName} onChange={handleChange} className="pr-10 bg-gray-50 focus:bg-white" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="customerPhone">رقم الهاتف (اختياري)</Label>
                      <div className="relative">
                        <Phone className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                        <Input id="customerPhone" name="customerPhone" value={formData.customerPhone} onChange={handleChange} dir="ltr" className="pr-10 bg-gray-50 focus:bg-white text-right" />
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="customerAddress" className="font-bold">العنوان التفصيلي <span className="text-destructive">*</span></Label>
                    <Textarea 
                      id="customerAddress" 
                      name="customerAddress" 
                      value={formData.customerAddress} 
                      onChange={handleChange} 
                      placeholder="اسم الشارع، رقم المبنى، الطابق، الشقة..."
                      required
                      className="bg-gray-50 focus:bg-white min-h-[100px]"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes">ملاحظات إضافية (اختياري)</Label>
                    <Textarea 
                      id="notes" 
                      name="notes" 
                      value={formData.notes} 
                      onChange={handleChange} 
                      placeholder="أية ملاحظات حول الطلب أو التوصيل..."
                      className="bg-gray-50 focus:bg-white"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="md:col-span-1">
              <Card className="shadow-sm sticky top-24">
                <CardHeader className="pb-4 border-b">
                  <CardTitle className="text-lg">الطلب ({items.length} عناصر)</CardTitle>
                </CardHeader>
                <CardContent className="pt-4 space-y-4">
                  <div className="max-h-[300px] overflow-y-auto pr-2 space-y-3">
                    {items.map(item => (
                      <div key={item.productId} className="flex justify-between text-sm">
                        <div className="flex gap-2">
                          <span className="font-medium text-gray-900">{item.quantity}x</span>
                          <span className="text-gray-600 line-clamp-1">{item.productName}</span>
                        </div>
                        <span className="text-gray-900 whitespace-nowrap">{(item.price * item.quantity).toFixed(2)} ج.م</span>
                      </div>
                    ))}
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between items-center text-lg pt-2">
                    <span className="font-bold">الإجمالي</span>
                    <span className="font-bold text-primary">{total.toFixed(2)} ج.م</span>
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full h-12 text-base font-bold mt-4 shadow-sm" 
                    disabled={createOrderMutation.isPending || !formData.customerAddress}
                  >
                    {createOrderMutation.isPending ? <Loader2 className="h-5 w-5 animate-spin ml-2" /> : <CheckCircle2 className="h-5 w-5 ml-2" />}
                    تأكيد الطلب
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </form>
      </div>
    </ShopLayout>
  );
}
