import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/lib/auth";
import { CartProvider } from "@/lib/cart";

// Pages
import NotFound from "@/pages/not-found";
import Login from "@/pages/login";
import Home from "@/pages/home";
import Cart from "@/pages/cart";
import Checkout from "@/pages/checkout";
import Invoice from "@/pages/invoice";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminProducts from "@/pages/admin/products";
import AdminOrders from "@/pages/admin/orders";
import PosSettings from "@/pages/admin/pos-settings";
import AdminSettings from "@/pages/admin/settings";
import { useEffect } from "react";
import { Loader2 } from "lucide-react";

const queryClient = new QueryClient();

function ProtectedRoute({ component: Component, adminOnly = false }: { component: any, adminOnly?: boolean }) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        setLocation("/login");
      } else if (adminOnly && user.role !== "admin") {
        setLocation("/");
      }
    }
  }, [user, isLoading, adminOnly, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-[100dvh] flex items-center justify-center bg-gray-50">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user || (adminOnly && user.role !== "admin")) {
    return null;
  }

  return <Component />;
}

function AppRouter() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      
      {/* Customer Routes */}
      <Route path="/">{() => <ProtectedRoute component={Home} />}</Route>
      <Route path="/cart">{() => <ProtectedRoute component={Cart} />}</Route>
      <Route path="/checkout">{() => <ProtectedRoute component={Checkout} />}</Route>
      <Route path="/invoice/:id">{() => <ProtectedRoute component={Invoice} />}</Route>
      
      {/* Admin Routes */}
      <Route path="/admin">{() => <ProtectedRoute component={AdminDashboard} adminOnly />}</Route>
      <Route path="/admin/products">{() => <ProtectedRoute component={AdminProducts} adminOnly />}</Route>
      <Route path="/admin/orders">{() => <ProtectedRoute component={AdminOrders} adminOnly />}</Route>
      <Route path="/admin/pos-settings">{() => <ProtectedRoute component={PosSettings} adminOnly />}</Route>
      <Route path="/admin/settings">{() => <ProtectedRoute component={AdminSettings} adminOnly />}</Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <AuthProvider>
          <CartProvider>
            <TooltipProvider>
              <AppRouter />
              <Toaster />
            </TooltipProvider>
          </CartProvider>
        </AuthProvider>
      </WouterRouter>
    </QueryClientProvider>
  );
}

export default App;
