import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.post("/auth/login", async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    res.status(400).json({ error: "اسم المستخدم وكلمة المرور مطلوبان" });
    return;
  }

  const users = await db.select().from(usersTable).where(eq(usersTable.username, username));
  const user = users[0];

  if (!user || user.password !== password) {
    res.status(401).json({ error: "اسم المستخدم أو كلمة المرور غير صحيحة" });
    return;
  }

  (req.session as any).userId = user.id;
  (req.session as any).role = user.role;

  res.json({
    user: { id: user.id, username: user.username, role: user.role, name: user.name },
    message: "تم تسجيل الدخول بنجاح",
  });
});

router.post("/auth/logout", (req, res) => {
  req.session.destroy(() => {
    res.json({ success: true, message: "تم تسجيل الخروج" });
  });
});

router.get("/auth/me", async (req, res) => {
  const userId = (req.session as any).userId;
  if (!userId) {
    res.status(401).json({ error: "غير مصرح" });
    return;
  }

  const users = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  const user = users[0];
  if (!user) {
    res.status(401).json({ error: "المستخدم غير موجود" });
    return;
  }

  res.json({ id: user.id, username: user.username, role: user.role, name: user.name });
});

router.post("/auth/change-password", async (req, res) => {
  const sessionUserId = (req.session as any).userId;
  const sessionRole = (req.session as any).role;

  if (!sessionUserId || sessionRole !== "admin") {
    res.status(403).json({ error: "غير مصرح. يجب أن تكون مسجلاً كمدير." });
    return;
  }

  const { targetUsername, currentPassword, newPassword } = req.body;

  if (!targetUsername || !currentPassword || !newPassword) {
    res.status(400).json({ error: "جميع الحقول مطلوبة." });
    return;
  }

  if (newPassword.length < 4) {
    res.status(400).json({ error: "كلمة المرور يجب أن تكون 4 أحرف على الأقل." });
    return;
  }

  const admins = await db.select().from(usersTable).where(eq(usersTable.id, sessionUserId));
  const adminUser = admins[0];
  if (!adminUser || adminUser.password !== currentPassword) {
    res.status(401).json({ error: "كلمة المرور الحالية للأدمن غير صحيحة." });
    return;
  }

  const targets = await db.select().from(usersTable).where(eq(usersTable.username, targetUsername));
  const targetUser = targets[0];
  if (!targetUser) {
    res.status(404).json({ error: "المستخدم غير موجود." });
    return;
  }

  await db.update(usersTable).set({ password: newPassword }).where(eq(usersTable.username, targetUsername));

  res.json({ success: true, message: `تم تغيير كلمة مرور "${targetUsername}" بنجاح.` });
});

export default router;
