import { Router } from "express";
import { db, productsTable } from "@workspace/db";
import { eq, ilike, sql } from "drizzle-orm";

const router = Router();

router.get("/products", async (req, res) => {
  const { search, category } = req.query as { search?: string; category?: string };

  let query = db.select().from(productsTable).$dynamic();

  if (search) {
    query = query.where(ilike(productsTable.name, `%${search}%`));
  } else if (category) {
    query = query.where(eq(productsTable.category, category));
  }

  const products = await query;
  res.json(products.map((p) => ({
    ...p,
    price: Number(p.price),
  })));
});

router.post("/products", async (req, res) => {
  const role = (req.session as any).role;
  if (role !== "admin") {
    res.status(403).json({ error: "غير مصرح لك" });
    return;
  }

  const { name, price, quantity, category, imageUrl, description } = req.body;
  if (!name || price === undefined || quantity === undefined || !category) {
    res.status(400).json({ error: "البيانات المطلوبة ناقصة" });
    return;
  }

  const inserted = await db.insert(productsTable).values({
    name,
    price: String(price),
    quantity: Number(quantity),
    category,
    imageUrl: imageUrl || null,
    description: description || null,
  }).returning();

  const p = inserted[0];
  res.status(201).json({ ...p, price: Number(p.price) });
});

router.get("/products/:id", async (req, res) => {
  const id = Number(req.params.id);
  const products = await db.select().from(productsTable).where(eq(productsTable.id, id));
  const p = products[0];
  if (!p) {
    res.status(404).json({ error: "المنتج غير موجود" });
    return;
  }
  res.json({ ...p, price: Number(p.price) });
});

router.put("/products/:id", async (req, res) => {
  const role = (req.session as any).role;
  if (role !== "admin") {
    res.status(403).json({ error: "غير مصرح لك" });
    return;
  }

  const id = Number(req.params.id);
  const { name, price, quantity, category, imageUrl, description } = req.body;

  const updateData: Record<string, unknown> = {};
  if (name !== undefined) updateData.name = name;
  if (price !== undefined) updateData.price = String(price);
  if (quantity !== undefined) updateData.quantity = Number(quantity);
  if (category !== undefined) updateData.category = category;
  if (imageUrl !== undefined) updateData.imageUrl = imageUrl;
  if (description !== undefined) updateData.description = description;

  const updated = await db.update(productsTable).set(updateData).where(eq(productsTable.id, id)).returning();
  const p = updated[0];
  if (!p) {
    res.status(404).json({ error: "المنتج غير موجود" });
    return;
  }
  res.json({ ...p, price: Number(p.price) });
});

router.delete("/products/:id", async (req, res) => {
  const role = (req.session as any).role;
  if (role !== "admin") {
    res.status(403).json({ error: "غير مصرح لك" });
    return;
  }

  const id = Number(req.params.id);
  await db.delete(productsTable).where(eq(productsTable.id, id));
  res.json({ success: true, message: "تم حذف المنتج" });
});

export default router;
