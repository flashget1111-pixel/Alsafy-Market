import { Router } from "express";
import { db, ordersTable, productsTable } from "@workspace/db";
import { eq, desc, sql, lt } from "drizzle-orm";

const router = Router();

router.get("/dashboard/stats", async (req, res) => {
  const role = (req.session as any).role;
  if (role !== "admin") {
    res.status(403).json({ error: "غير مصرح لك" });
    return;
  }

  const [productCount] = await db.select({ count: sql<number>`count(*)::int` }).from(productsTable);
  const [orderCount] = await db.select({ count: sql<number>`count(*)::int` }).from(ordersTable);
  const [pendingCount] = await db.select({ count: sql<number>`count(*)::int` })
    .from(ordersTable).where(eq(ordersTable.status, "pending"));
  const [completedCount] = await db.select({ count: sql<number>`count(*)::int` })
    .from(ordersTable).where(eq(ordersTable.status, "completed"));
  const [revenue] = await db.select({ total: sql<number>`coalesce(sum(total_amount), 0)::float` })
    .from(ordersTable).where(eq(ordersTable.status, "completed"));
  const [lowStock] = await db.select({ count: sql<number>`count(*)::int` })
    .from(productsTable).where(lt(productsTable.quantity, 5));

  res.json({
    totalProducts: productCount.count,
    totalOrders: orderCount.count,
    totalRevenue: revenue.total,
    pendingOrders: pendingCount.count,
    completedOrders: completedCount.count,
    lowStockCount: lowStock.count,
  });
});

router.get("/dashboard/low-stock", async (req, res) => {
  const role = (req.session as any).role;
  if (role !== "admin") {
    res.status(403).json({ error: "غير مصرح لك" });
    return;
  }

  const products = await db.select().from(productsTable).where(lt(productsTable.quantity, 5));
  res.json(products.map((p) => ({ ...p, price: Number(p.price) })));
});

router.get("/dashboard/recent-orders", async (req, res) => {
  const role = (req.session as any).role;
  if (role !== "admin") {
    res.status(403).json({ error: "غير مصرح لك" });
    return;
  }

  const orders = await db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt)).limit(10);
  res.json(orders.map((o) => ({
    ...o,
    totalAmount: Number(o.totalAmount),
    createdAt: o.createdAt instanceof Date ? o.createdAt.toISOString() : o.createdAt,
  })));
});

export default router;
