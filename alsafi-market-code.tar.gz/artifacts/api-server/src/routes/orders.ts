import { Router } from "express";
import { db, ordersTable, productsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

function formatOrder(o: any) {
  return {
    ...o,
    totalAmount: Number(o.totalAmount),
    createdAt: o.createdAt instanceof Date ? o.createdAt.toISOString() : o.createdAt,
  };
}

router.get("/orders", async (req, res) => {
  const userId = (req.session as any).userId;
  const role = (req.session as any).role;

  if (!userId) {
    res.status(401).json({ error: "غير مصرح" });
    return;
  }

  let orders;
  if (role === "admin") {
    orders = await db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt));
  } else {
    orders = await db.select().from(ordersTable)
      .where(eq(ordersTable.userId, userId))
      .orderBy(desc(ordersTable.createdAt));
  }

  res.json(orders.map(formatOrder));
});

router.post("/orders", async (req, res) => {
  const userId = (req.session as any).userId;
  if (!userId) {
    res.status(401).json({ error: "غير مصرح" });
    return;
  }

  const { customerName, customerPhone, customerAddress, notes, items } = req.body;

  if (!customerAddress || !items || !Array.isArray(items) || items.length === 0) {
    res.status(400).json({ error: "العنوان والمنتجات مطلوبة" });
    return;
  }

  const orderItems = [];
  let totalAmount = 0;

  for (const item of items) {
    const products = await db.select().from(productsTable).where(eq(productsTable.id, item.productId));
    const product = products[0];

    if (!product) {
      res.status(404).json({ error: `المنتج ${item.productId} غير موجود` });
      return;
    }

    if (product.quantity < item.quantity) {
      res.status(400).json({ error: `الكمية المطلوبة من ${product.name} غير متوفرة` });
      return;
    }

    const unitPrice = Number(product.price);
    const totalPrice = unitPrice * item.quantity;
    totalAmount += totalPrice;

    orderItems.push({
      productId: product.id,
      productName: product.name,
      quantity: item.quantity,
      unitPrice,
      totalPrice,
    });

    await db.update(productsTable)
      .set({ quantity: product.quantity - item.quantity })
      .where(eq(productsTable.id, product.id));
  }

  const orderNumber = `SAF-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

  const inserted = await db.insert(ordersTable).values({
    orderNumber,
    customerName: customerName || null,
    customerPhone: customerPhone || null,
    customerAddress,
    notes: notes || null,
    status: "pending",
    totalAmount: String(totalAmount),
    items: orderItems,
    userId,
  }).returning();

  res.status(201).json(formatOrder(inserted[0]));
});

router.get("/orders/:id", async (req, res) => {
  const userId = (req.session as any).userId;
  const role = (req.session as any).role;

  if (!userId) {
    res.status(401).json({ error: "غير مصرح" });
    return;
  }

  const id = Number(req.params.id);
  const orders = await db.select().from(ordersTable).where(eq(ordersTable.id, id));
  const order = orders[0];

  if (!order) {
    res.status(404).json({ error: "الطلب غير موجود" });
    return;
  }

  if (role !== "admin" && order.userId !== userId) {
    res.status(403).json({ error: "غير مصرح لك" });
    return;
  }

  res.json(formatOrder(order));
});

router.put("/orders/:id", async (req, res) => {
  const role = (req.session as any).role;
  if (role !== "admin") {
    res.status(403).json({ error: "غير مصرح لك" });
    return;
  }

  const id = Number(req.params.id);
  const { status } = req.body;

  const validStatuses = ["pending", "processing", "completed", "cancelled"];
  if (!status || !validStatuses.includes(status)) {
    res.status(400).json({ error: "حالة الطلب غير صحيحة" });
    return;
  }

  const updated = await db.update(ordersTable)
    .set({ status })
    .where(eq(ordersTable.id, id))
    .returning();

  const order = updated[0];
  if (!order) {
    res.status(404).json({ error: "الطلب غير موجود" });
    return;
  }

  res.json(formatOrder(order));
});

export default router;
